# gae-devops-reaction-telegram-bot

======
HOW TO
======

1. Update ``<TOKEN>`` on `main.py`.

2. Update ``<GAE PROJECT NAME>`` on `app.yaml`.

2. `$ mkdir lib`

3. `$ pip install -t lib python-telegram-bot BeautifulSoup`

4. `$ appcfg.py -A <APP_NAME> update .`
